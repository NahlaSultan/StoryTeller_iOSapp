//
//  StoryBrain.swift
//  Destini-iOS13
//
//  Created by Angela Yu on 08/08/2019.
//  Copyright © 2019 The App Brewery. All rights reserved.
//

import Foundation

struct StoryBrian {
    let stories = [
        Story(text:"You see a fork in the road.",choice1:"Take a left.",choice2:"Take a right.", choice1Next: 1, choice2Next: 2),
        
        Story(text:"You see a tiger.",choice1:"Play dead.",choice2:"Run for your life.", choice1Next: 3, choice2Next: 4),
       
        Story(text:"You find a treasure chest.",choice1:"Open it.",choice2:"Check for traps.", choice1Next: 6, choice2Next: 5),
        
        Story(text:"You didn't fool the tiger, instead you gave him a free lunch.",choice1:"The",choice2:"End", choice1Next: 0, choice2Next: 0),
        
        Story(text:"You find a tribe and live with them forever.",choice1:"The",choice2:"End", choice1Next: 0, choice2Next: 0),
        
        Story(text:"You find a bomb and 3 mouse traps, guess we'll never know when the bomb will go off.",choice1:"The",choice2:"End", choice1Next: 0, choice2Next: 0),
        
        Story(text:"You find human bones, and then you go home in disappointment.",choice1:"The",choice2:"End", choice1Next: 0, choice2Next: 0)
        
        
    ]
    var currentStory = 0
    
    
    mutating func nextStory(choice:String){
        
        let cur = stories[currentStory]
        
        if choice == cur.choice1{
            currentStory = cur.choice1Next
        }
        else if choice == cur.choice2{
                   currentStory = cur.choice2Next
               }
        else{
            currentStory = 0
        }
        
    }
}

